from django.contrib import admin

from .models import Review, Ticket

class TicketAdmin(admin.ModelAdmin):
    list_display = ('titre', 'description', 'time_created')

class ReviewAdmin(admin.ModelAdmin):
    list_display = ('headline', 'body', 'time_created')
# Register your models here.

admin.site.register(Ticket, TicketAdmin)
