from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views import generic
from .forms import SignupForm

from . import forms

from django.shortcuts import render


class SignUpView(generic.CreateView):
    form_class = SignupForm
    success_url = reverse_lazy("login")
    template_name = 'authentication/signup.html'


def upload_profile_photo(request):
    form = forms.UploadProfilePhotoForm(instance=request.user)
    if request.method == 'POST':
        form = forms.UploadProfilePhotoForm(request.POST, request.FILES,
                                            instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('home')
    return render(request, 'authentication/upload_profile_photo.html',
                  context={'form': form})
